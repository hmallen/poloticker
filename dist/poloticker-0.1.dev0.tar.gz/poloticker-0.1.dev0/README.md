# PoloTicker
MongoDB-based OHLC ticker for Poloniex markets with Slack integration, using websockets as data feed.
